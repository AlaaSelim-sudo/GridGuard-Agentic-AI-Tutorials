# GridGuard participant labs

**Alaa Selim, MIT/Dartmouth; Mohamed Chehada, UT Austin.**

Start with **Classroom_Labs.ipynb**. It covers all three hands-on cases.

## Run in Colab

[Open Classroom Labs](https://colab.research.google.com/github/AlaaSelim-sudo/GridGuard-Agentic-AI-Tutorials/blob/main/agentic_grid_workflow_tutorial/Classroom_Labs.ipynb).

Save a Drive copy, connect a CPU runtime, run setup and wait for Ready. Start at L0 and continue through L12, including L10B. Keep RUN_OPENDSS and RUN_LOCAL_LLAMA False. No GPU, API key or language-model download is needed.

## Run locally

1. Extract this folder and create/activate a Python virtual environment.
2. Open a terminal in this folder, where src and data are visible.
3. Run `python -m pip install -r requirements_local.txt`.
4. Run `python -m jupyter lab Classroom_Labs.ipynb`.

## Explore

- Voltage L2-L5: compare proposals and check model limits.
- Restoration L6-L7: compare total and critical load served.
- Cyber L8-L9: compare residual consistency and state error.
- L10-L10B: inspect actual saved agent choices and tool results.
- L12: inspect the simulated recommendation readback.

Change one exercise input at a time and reset before continuing. The two notebooks in companions are separate graph and evidence activities. Start Jupyter from this root folder when opening them.

## Supporting files

src, data, models and results are supporting files; you do not need to edit them. Sources and model limits are documented in the code, records and data/DATA_SOURCE.md. PARTICIPANT_MANIFEST.json identifies the supplied files.

The cases use synthetic or reduced networks. Python makes fresh calculations; saved model replies are labeled separately. L10B makes no new model call or electrical solve. No lab operates equipment. Advanced live-model or OpenDSS paths need separately prepared software and study files.

[Presentations and references](https://alaaselim-sudo.github.io/GridGuard-Agentic-AI-Tutorials/) · [Source code](https://github.com/AlaaSelim-sudo/GridGuard-Agentic-AI-Tutorials/blob/main/agentic_grid_workflow_tutorial/).
